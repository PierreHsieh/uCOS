
#ifndef  APP_WEBPAGES_PRESENT
#define  APP_WEBPAGES_PRESENT


#define  STATIC_LOGO_GIF_NAME               "\\logo.gif"
#define  STATIC_INDEX_HTML_NAME             "\\index.html"

#define  STATIC_LOGO_GIF_LEN                2066u
#define  STATIC_INDEX_HTML_LEN              3080u


extern const unsigned char logo_gif[];
extern const unsigned char index_html[];

#endif
