/*
*********************************************************************************************************
*                                       EXAMPLE CODE
*
*               This file is provided as an example on how to use Micrium products.
*
*               Please feel free to use any application code labeled as 'EXAMPLE CODE' in
*               your application products.  Example code may be used as is, in whole or in
*               part, or may be used as a reference only. This file can be modified as
*               required to meet the end-product requirements.
*
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*
*               You can find our product's user manual, API reference, release notes and
*               more information at https://doc.micrium.com.
*
*               You can contact us at www.micrium.com.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                                EXAMPLE
*
*                                  HTTP CLIENT APPLICATION FUNCTIONS FILE
*
* Filename      : http-c_app.c
* Version       : V1.00.00
* Programmer(s) : MM
*********************************************************************************************************
* Note(s)       : (1) Assumes the following versions (or more recent) of software modules are included in
*                     the project build :
*
*                       (a) uC/CPU    V1.29.02
*                       (b) uC/LIB    V1.38.00
*                       (c) uC/Common V1.00.00
*                       (d) uC/TCP-IP V3.02.00
*
*
*                 (2) For additional details on the features available with uC/HTTPc, the API, the
*                     installation, etc. Please refer to the uC/HTTPc documentation available at
*                     https://doc.micrium.com/HTTPc.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*********************************************************************************************************
*                                               MODULE
*********************************************************************************************************
*********************************************************************************************************
*/

#ifndef  HTTPc_APP_MODULE_PRESENT
#define  HTTPc_APP_MODULE_PRESENT

/*
*********************************************************************************************************
*                                             FS MODULE
*
* Note(s): If the �C/FS is present in the project, you can enable it for the example application.
*********************************************************************************************************
*/

#define  HTTPc_APP_FS_MODULE_PRESENT   DEF_NO


/*
*********************************************************************************************************
*********************************************************************************************************
*                                           INCLUDE FILES
*********************************************************************************************************
*********************************************************************************************************
*/

#include  <Client/Source/http-c.h>

#if (HTTPc_APP_FS_MODULE_PRESENT == DEF_YES)
#include  <fs_file.h>
#include  <fs_type.h>
#endif


/*
*********************************************************************************************************
*********************************************************************************************************
*                                               EXTERNS
*********************************************************************************************************
*********************************************************************************************************
*/

#ifdef HTTPc_APP_MODULE
#define  HTTPc_APP_EXT
#else
#define  HTTPc_APP_EXT  extern
#endif


/*
*********************************************************************************************************
*********************************************************************************************************
*                                             DEFINES
*********************************************************************************************************
*********************************************************************************************************
*/


#define  HTTP_SERVER_HOSTNAME                            "api.openweathermap.org"

#define  HTTPc_APP_CFG_URI                               "/data/2.5/weather"
#define  HTTPc_APP_CFG_QUERY_STR_CITY                    "fort.lauderdale,us"

#define  HTTPc_APP_CFG_CONN_NBR_MAX                       5u
#define  HTTPc_APP_CFG_REQ_NBR_MAX                        5u
#define  HTTPc_APP_CFG_CONN_BUF_SIZE                    512u

#define  HTTPc_APP_CFG_QUERY_STR_NBR_MAX                  1u
#define  HTTPc_APP_CFG_QUERY_STR_KEY_LEN_MAX             20u
#define  HTTPc_APP_CFG_QUERY_STR_VAL_LEN_MAX             50u

#define  HTTPc_APP_CFG_HDR_NBR_MAX                        6u
#define  HTTPc_APP_CFG_HDR_VAL_LEN_MAX                  100u

#define  HTTPc_APP_CFG_FORM_BUF_SIZE                    256u
#define  HTTPc_APP_CFG_FORM_FIELD_NBR_MAX                10u
#define  HTTPc_APP_CFG_FORM_FIELD_KEY_LEN_MAX           100u
#define  HTTPc_APP_CFG_FORM_FIELD_VAL_LEN_MAX           200u
#define  HTTPc_APP_CFG_FORM_MULTIPART_NAME_LEN_MAX      100u
#define  HTTPc_APP_CFG_FORM_MULTIPART_FILENAME_LEN_MAX  100u


/*
*********************************************************************************************************
*********************************************************************************************************
*                                          LOCAL DATA TYPES
*********************************************************************************************************
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                          CONNECTION DATA TYPE
*********************************************************************************************************
*/

typedef  struct  httpc_app_conn_data {
    CPU_BOOLEAN   Close;
} HTTPc_APP_CONN_DATA;


/*
*********************************************************************************************************
*                                           REQUEST DATA TYPE
*********************************************************************************************************
*/

typedef  struct  httpc_app_req_data {
    CPU_BOOLEAN   Done;
    CPU_INT08U    QueryStrIx;
    CPU_INT16U    FormIx;
#if (HTTPc_APP_FS_MODULE_PRESENT == DEF_YES)
    FS_FILE      *FilePtr;
#endif
} HTTPc_APP_REQ_DATA;


/*
*********************************************************************************************************
*********************************************************************************************************
*                                         GLOBAL VARIABLES
*********************************************************************************************************
*********************************************************************************************************
*/

HTTPc_APP_EXT  HTTPc_APP_REQ_DATA    HTTPcApp_Data[HTTPc_APP_CFG_REQ_NBR_MAX];

HTTPc_APP_EXT  CPU_CHAR              HTTPcApp_Buf[2048];

HTTPc_APP_EXT  HTTPc_CONN_OBJ        HTTPcApp_ConnTbl[HTTPc_APP_CFG_CONN_NBR_MAX];
HTTPc_APP_EXT  HTTPc_REQ_OBJ         HTTPcApp_ReqTbl[HTTPc_APP_CFG_REQ_NBR_MAX];
HTTPc_APP_EXT  HTTPc_RESP_OBJ        HTTPcApp_RespTbl[HTTPc_APP_CFG_REQ_NBR_MAX];

HTTPc_APP_EXT  CPU_CHAR              HTTPcApp_ConnBufTbl[HTTPc_APP_CFG_CONN_NBR_MAX][HTTPc_APP_CFG_CONN_BUF_SIZE];

HTTPc_APP_EXT  HTTPc_KEY_VAL         HTTPcApp_ReqQueryStrTbl[HTTPc_APP_CFG_QUERY_STR_NBR_MAX];
HTTPc_APP_EXT  CPU_CHAR              HTTPcApp_ReqQueryStrKeyTbl[HTTPc_APP_CFG_QUERY_STR_NBR_MAX][HTTPc_APP_CFG_QUERY_STR_KEY_LEN_MAX];
HTTPc_APP_EXT  CPU_CHAR              HTTPcApp_ReqQueryStrValTbl[HTTPc_APP_CFG_QUERY_STR_NBR_MAX][HTTPc_APP_CFG_QUERY_STR_VAL_LEN_MAX];


/*
*********************************************************************************************************
*********************************************************************************************************
*                                         FUNCTION PROTOTYPES
*********************************************************************************************************
*********************************************************************************************************
*/

CPU_BOOLEAN  HTTPcApp_Init                 (void);

CPU_BOOLEAN  HTTPcApp_PersistentConn       (void);

CPU_BOOLEAN  HTTPcApp_ReqWeather           (void);

CPU_BOOLEAN  HTTPcApp_CloseConn            (void);


/*
*********************************************************************************************************
*********************************************************************************************************
*                                              MODULE END
*********************************************************************************************************
*********************************************************************************************************
*/

#endif  /* HTTPc_APP_MODULE_PRESENT  */

