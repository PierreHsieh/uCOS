/*
*********************************************************************************************************
*                                               uC/OS-View
*
*                           (c) Copyright 1992-2002, Jean J. Labrosse, Weston, FL
*                                           All Rights Reserved
*
;                                             Mitsubishi M16C
*********************************************************************************************************
*/

#include "includes.h"

/*
*********************************************************************************************************
*                                               CONSTANTS
*********************************************************************************************************
*/
/*
*********************************************************************************************************
*                                              CONSTANTS 
*********************************************************************************************************
*/

#ifndef  OS_VIEW_BAUD_DIVIDE
#define  OS_VIEW_BAUD_DIVIDE     ((CPU_CLK_FREQ + (OS_VIEW_BAUDRATE * 8L)) / (OS_VIEW_BAUDRATE * 16L)) - 1
#endif

/*$PAGE*/
/*
*********************************************************************************************************
*                                           EXIT uC/OS-View
*
* Description: 
*
* Note(s)    : 
*********************************************************************************************************
*/

void  OSView_Exit (void)
{
}

/*
*********************************************************************************************************
*                                           Obtain CPU name 
*********************************************************************************************************
*/

void  OSView_GetCPUName (char *s)
{
    strcpy(s, "M16C/80");
}

/*
*********************************************************************************************************
*                                  Obtain Interrupt Stack information
*********************************************************************************************************
*/

INT32U  OSView_GetIntStkBase (void)					  
{
    return (0);										  /* We are not using an ISR stack                 */
}


INT32U  OSView_GetIntStkSize (void)
{
    return (0);										  /* We are not using an ISR stack                 */
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                    INITIALISE uC/OS-View COM PORT
*
* Description: Initialize the hardware required for the OS to run. This will work on any target hardware, 
*              but may have to be tailored a little (regarding the clock frequency). Of course the same 
*              holds true if for some reason you choose to use an other timer.
*
* Note(s)    : 1) Assumes UART #0
*********************************************************************************************************
*/

void  OSView_InitTarget (void)
{
    U0MR   = 0x00;                                   /* lock Sio, error reset                          */
    U0C0   = 0x10;                                   /* RTS/CTS disabled, clock divisor 1              */
    U0BRG  = OS_VIEW_BAUD_DIVIDE;                    /* Calculated Baudrate                            */
    U0C1   =    0;                                   /* Lock Rx and Tx                                 */
    U0MR   = 0x05;                                   /*    8  Data                                     */
                                                     /*    0: 1 Stop-Bit (1= 2 Stop-Bits)              */
                                                     /*    X: Parity select                            */
                                                     /*    1: parity enable                            */
                                                     /*    0: no sleep                                 */
    U0C1   =    5;                                   /* enable reception and transmition               */
    S0RIC  =    1;                                   /* Enable UART Rx interrupts                      */
    S0TIC  =    1;                                   /* Enable UART Tx interrupts                      */
    PD6   |= 0x08;                                   /* Direction register   (0=IN 1=OUT)              */
    P6    |= 0x08;                                   /* Register  (0=Low, 1= High)                     */
    PS0   |= 0x08;                                   /* Enable Tx0                                     */
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                       Disable Rx Interrupts
*********************************************************************************************************
*/

void  OSView_RxIntDis (void) 
{
}

/*
*********************************************************************************************************
*                                       Enable Rx Interrupts
*********************************************************************************************************
*/

void  OSView_RxIntEn (void) 
{
}

/*
*********************************************************************************************************
*                                 Rx Communication handler for uC/OS-View
*
* Description: This function is called by OSView_RxISR (see OS_VIEWa.ASM) to process a received
*              character interrupt.
*********************************************************************************************************
*/

void  OSView_RxISRHandler (void) 
{
    INT8U   data_low;
	INT8U   data_high;
    INT16U  data;


    OS_ENTER_CRITICAL();
	data_low  = U0RBL;
	data_high = U0RBH;
    data      = (data_high << 8) | data_low;
    if (data & 0x6000) {                             /* Check if errors occurred                       */
        U0C1 &= ~0x04;                               /* disable Rx                                     */
        U0C1 |=  0x04;                               /* enable  Rx                                     */
    } else {
        OSView_RxHandler(data);						 /* Call the generic Rx handler                    */
    }
    OS_EXIT_CRITICAL();
}

/*
*********************************************************************************************************
*                                Rx/Tx Communication handler for uC/OS-View
*
* Description: This function is NOT called because the M16C has a separate Rx and Tx ISR.
*********************************************************************************************************
*/

void  OSView_RxTxISRHandler (void) 
{
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                              Tick Hook
*
* This routine is called by uC/OS-II's OSTimeTickHook().
*********************************************************************************************************
*/

void  OSView_TickHook (void) 
{
}

/*
*********************************************************************************************************
*                                           Get time [cycles]
*
* This routine is required for task-info via uC/OS-View.
* It returns the system time in clock cycles.
*********************************************************************************************************
*/

INT32U  OSView_TimeGetCycles (void) 
{
    INT16U  t_cnt;
    INT32U  time;
    INT32U  cycles;
    
     
    OS_ENTER_CRITICAL();
    t_cnt = TA0;  
    time  = OSTime + 1;  
    if (TA0IC & 0x08) {                              /* See if we had an overflow                      */
        t_cnt = TA0;
        time++;
    }
    cycles = ((INT32U)CPU_CLK_FREQ / (INT32U)OS_TICKS_PER_SEC) * time - t_cnt;
    OS_EXIT_CRITICAL();
    return (cycles);
}

/*
*********************************************************************************************************
*                                      Communication for uC/OS-View
*
* Description: Send 1 character to COM Port
*
* Note(s)    : 1) Assumes UART #0
*********************************************************************************************************
*/

void  OSView_Tx1 (INT8U c) 
{
    U0TBL = c;
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                       Disable Tx Interrupts
*********************************************************************************************************
*/

void  OSView_TxIntDis (void) 
{
}

/*
*********************************************************************************************************
*                                       Enable Tx Interrupts
*********************************************************************************************************
*/

void  OSView_TxIntEn (void) 
{
}

/*
*********************************************************************************************************
*                                 Tx Communication handler for uC/OS-View
*                                            (PORT SPECIFIC)
*
* Description: Handle transmission of a character
*
* Note(s)    : 1) This function is called by OSView_RxISR (see OS_VIEWa.ASM)
*********************************************************************************************************
*/

void  OSView_TxISRHandler (void) 
{
    OSView_TxHandler();
}

