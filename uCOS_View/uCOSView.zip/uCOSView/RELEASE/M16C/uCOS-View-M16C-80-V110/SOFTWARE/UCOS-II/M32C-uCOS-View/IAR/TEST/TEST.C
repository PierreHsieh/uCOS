/*
*********************************************************************************************************
*                                                uC/OS-II
*                                          The Real-Time Kernel
*
*                           (c) Copyright 1992-2002, Jean J. Labrosse, Weston, FL
*                                           All Rights Reserved
*
*                                               EXAMPLE #1
*********************************************************************************************************
*/

#include "includes.h"

/*
*********************************************************************************************************
*                                               CONSTANTS
*********************************************************************************************************
*/

#define  TEST_TASK_STK_SIZE                 256            /* Size of each task's stacks (# of WORDs)  */

#define  TEST_TASK5_STK_SIZE               1536            /* Size of the GUI task stack (# of WORDs)  */

/*
*********************************************************************************************************
*                                               VARIABLES
*********************************************************************************************************
*/

OS_STK             TestStartStk[TEST_TASK_STK_SIZE];
OS_STK             TestTask2Stk[TEST_TASK_STK_SIZE];
OS_STK             TestTask3Stk[TEST_TASK_STK_SIZE];
OS_STK             TestTask4Stk[TEST_TASK_STK_SIZE];

OS_EVENT          *SemPtr;
OS_EVENT          *MboxPtr;
OS_EVENT          *QPtr;
void              *QTbl[10];
OS_EVENT          *MutexPtr;
OS_FLAG_GRP       *FlagPtr;

/*
*********************************************************************************************************
*                                           FUNCTION PROTOTYPES
*********************************************************************************************************
*/

static  void  TestStart(void *pdata);                      /* Function prototypes of Startup task      */
static  void  TestTerminalRx(INT8U data);
static  void  TestCreateTasks(void);
static  void  TestTask2(void *pdata);
static  void  TestTask3(void *pdata);
static  void  TestTask4(void *pdata);
static  void  TestInitTick(void);
static  void  TestInitIO(void);

/*$PAGE*/
/*
*********************************************************************************************************
*                                                MAIN
*********************************************************************************************************
*/

void  main (void)
{
    INT8U   task_prio;
    INT8U   err;


    OSInit();                                              /* Initialize uC/OS-II                      */

    SemPtr   = OSSemCreate(0);
    MboxPtr  = OSMboxCreate((void *)0);
    QPtr     = OSQCreate(&QTbl[0], 10);
    MutexPtr = OSMutexCreate(5, &err);
    FlagPtr  = OSFlagCreate(0x0000, &err);

    task_prio = 10;
    OSTaskCreateExt(TestStart,
                    (void *)0,
                    &TestStartStk[TEST_TASK_STK_SIZE - 1],
                    task_prio,
                    task_prio,
                    &TestStartStk[0],
                    TEST_TASK_STK_SIZE,
                    (void *)0,
                    OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);
    OSTaskNameSet(task_prio, "LED Task", &err);

    OSStart();                                             /* Start multitasking                       */
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                      TERMINLA WINDOW CALLBACK
*********************************************************************************************************
*/

static  void  TestTerminalRx (INT8U data)
{

}

/*
*********************************************************************************************************
*                                       CREATE APPLICATION TASKS
*********************************************************************************************************
*/

static  void  TestCreateTasks (void)
{
    INT8U  task_prio;
    INT8U  err;


    task_prio = 20;
    OSTaskCreateExt(TestTask2,
                    (void *)0,
                    &TestTask2Stk[TEST_TASK_STK_SIZE - 1],
                    task_prio,
                    task_prio,
                    &TestTask2Stk[0],
                    TEST_TASK_STK_SIZE,
                    (void *)0,
                    OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);
    OSTaskNameSet(task_prio, "TestTask #2", &err);

    task_prio = 30;
    OSTaskCreateExt(TestTask3,
                    (void *)0,
                    &TestTask3Stk[TEST_TASK_STK_SIZE - 1],
                    task_prio,
                    task_prio,
                    &TestTask3Stk[0],
                    TEST_TASK_STK_SIZE,
                    (void *)0,
                    OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);
    OSTaskNameSet(task_prio, "TestTask #3", &err);

    task_prio = 40;
    OSTaskCreateExt(TestTask4,
                    (void *)0,
                    &TestTask4Stk[TEST_TASK_STK_SIZE - 1],
                    task_prio,
                    task_prio,
                    &TestTask4Stk[0],
                    TEST_TASK_STK_SIZE,
                    (void *)0,
                    OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);
    OSTaskNameSet(task_prio, "Pending Task", &err);
}

/*
*********************************************************************************************************
*                                            STARTUP TASK
*********************************************************************************************************
*/
static  void  TestStart (void *pdata)
{
#if OS_CRITICAL_METHOD == 3                                /* Allocate storage for CPU status register */
    OS_CPU_SR  cpu_sr;
#endif


    pdata = pdata;                                         /* Prevent compiler warning                 */
    TestInitTick();

	OSStatInit();										   /* Initialize uC/OS-II's statistic task     */

    TestInitIO();

    OSView_Init();

    OSView_TerminalRxSetCallback(TestTerminalRx);

    TestCreateTasks();

    while (TRUE) {
        P10       ^= 0x40;                                 /* Toggle LED every second                  */
        OSCtxSwCtr = 0;
        OSTimeDlyHMSM(0, 0, 1, 0);
    }
}

/*
*********************************************************************************************************
*                                               TASK #2
*********************************************************************************************************
*/
static  void  TestTask2 (void *pdata)
{
#if OS_CRITICAL_METHOD == 3                                /* Allocate storage for CPU status register */
    OS_CPU_SR  cpu_sr;
#endif
    INT16U  i;
    INT16U  j;


    pdata = pdata;                                         /* Prevent compiler warning                 */
    while (TRUE) {
        for (j = 0; j < 10; j++) {
            for (i = 0; i < (5000 * j); i++) {
            }
            OSTimeDly(OS_TICKS_PER_SEC);
        }
    }
}

/*
*********************************************************************************************************
*                                               TASK #3
*********************************************************************************************************
*/
static  void  TestTask3 (void *pdata)
{
#if OS_CRITICAL_METHOD == 3                                /* Allocate storage for CPU status register */
    OS_CPU_SR  cpu_sr;
#endif


    pdata = pdata;                                         /* Prevent compiler warning                 */
    while (TRUE) {
        OSTimeDlyHMSM(0, 0, 0, 50);
    }
}

/*
*********************************************************************************************************
*                                               TASK #4
*********************************************************************************************************
*/
static  void  TestTask4 (void *pdata)
{
#if OS_CRITICAL_METHOD == 3                                /* Allocate storage for CPU status register */
    OS_CPU_SR  cpu_sr;
#endif
    INT8U      err;


    pdata = pdata;                                         /* Prevent compiler warning                 */
    while (TRUE) {
        OSSemPend(SemPtr, 2500, &err);
        OSTimeDlyHMSM(0, 0, 4, 0);

        OSMboxPend(MboxPtr, 2500, &err);
        OSTimeDlyHMSM(0, 0, 4, 0);

        OSQPend(QPtr, 2500, &err);
        OSTimeDlyHMSM(0, 0, 4, 0);

        OSMutexPend(MutexPtr, 2500, &err);
        OSTimeDlyHMSM(0, 0, 4, 0);

        OSFlagPend(FlagPtr, 0x1111, OS_FLAG_WAIT_SET_ALL, 2500, &err);
        OSTimeDlyHMSM(0, 0, 4, 0);
    }
}

/*
*********************************************************************************************************
*                                          INITIALIZE I/Os
*
* Initialize the hardware required for the OS to run. This will work on any target hardware, but may have 
* to be tailored a little (regarding the clock frequency). Of course the same holds true if for some reason 
* you choose to use an other timer.
*********************************************************************************************************
*/

static  void  TestInitTick (void)
{
                                                     /* Generate tick interrupt @ OS_TICKS_PER_SEC     */
    TA0    = (INT16U)(((INT32U)CPU_CLK_FREQ / OS_TICKS_PER_SEC - 1));  
    TA0MR  = 0x00;                                   /* Timer mode register                            */
                                                     /* bit 01 : 00 Timer mode                         */
                                                     /* bit 2  :  0 No pulse output                    */
                                                     /* bit 34 : 0X No gate function                   */
                                                     /* bit 5  : 0                                     */
                                                     /* bit 67 : 00 clock source : fx/2                */
    TA0IC  = 0x01;                                   /* Timer interrupt register, priority 1 (lowest)  */
    TABSR |= 0x01;                                   /* Set Timer count start flag                     */
    PRCR   = 0x03;                                   /* Enable write to Processor mode                 */
    MCD    = 0x12;                                   /* main clock division register: no division      */
    PRCR   = 0x00;                                   /* Disable access to processor and clock mode     */

    PD10   = 0xFF;                                   /* Set P10 to all outputs (LED port)              */
}

/*
*********************************************************************************************************
*                                          INITIALIZE I/Os
*
* Initialize the CPU to interface with the LCD controller
*********************************************************************************************************
*/

void  TestInitIO (void) 
{
    P8     = 0x03;                                /* B0: RESET ETHERNET controller                     */
                                                  /* B1: RESET LCD                                     */
                                                  /* B2: input                                         */
                                                  /* B3: open                                          */
                                                  /* B4: open                                          */
                                                  /* B5: open                                          */
                                                  /* B6: open                                          */
                                                  /* B7: open                                          */

    PD8    = 0xFB;                                /* B0: RESET ETHERNET controller                     */
                                                  /* B1: RESET LCD                                     */
                                                  /* B2: IRQ input                                     */
                                                  /* B3: open                                          */
                                                  /* B4: open                                          */
                                                  /* B5: open                                          */
                                                  /* B6: open                                          */
                                                  /* B7: open                                          */

    PD10   = 0xFC;								  /* B0: AN0 in                                        */
                                                  /* B1: AN1 in                                        */
                                                  /* B2: X-                                            */
                                                  /* B3: Y-                                            */
                                                  /* B4: X+                                            */
                                                  /* B5: Y+                                            */
                                                  /* B6: OK-LED                                        */
                                                  /* B7: Err-LED                                       */
                                                  
    P10   |= 0xC0;                                /* B6: OK LED                                        */
                                                  /* B7: ERR LED                                       */

    PRCR   = 0x03;                                /* enable writes to CM                               */

    PM0    = 0x05;                                /* B0: \   01 : mem. expansion mode                  */
                                                  /* B1: /   11 : microprocessor mode                  */
                                                  /* B2: R/W mode select bit                           */
                                                  /* B3:                                               */
                                                  /* B4:                                               */
                                                  /* B5:                                               */
                                                  /* B6:                                               */
                                                  /* B7:                                               */

    PM1    = 0xC3;                                /* B0: \   P44-P47 are CS                            */
                                                  /* B1: /                                             */
                                                  /* B2:                                               */
                                                  /* B3:                                               */
                                                  /* B4:                                               */
                                                  /* B5:                                               */
                                                  /* B6: \   Must be 11 acc. to doc (page 25)          */
                                                  /* B7: /                                             */

    PRCR   = 0x00;                                /* Disable writes to CM                              */

    DS     = 0x0F;                                /* All CS areas use 16 bit data bus                  */

    WCR    = 0xFF;                                /* Define wait states                                */
}
