/*
*********************************************************************************************************
*                                                uC/OS-II
*                                          The Real-Time Kernel
*
*                           (c) Copyright 1992-2002, Jean J. Labrosse, Weston, FL
*                                           All Rights Reserved
*
*                                               EXAMPLE #1
*********************************************************************************************************
*/

#include "includes.h"

/*
*********************************************************************************************************
*                                               CONSTANTS
*********************************************************************************************************
*/

#define  TEST_TASK_STK_SIZE                 400       /* Size of each task's stacks (# of WORDs)       */

#define  TEST_N_TASKS                        10       /* Number of identical tasks                     */

/*
*********************************************************************************************************
*                                               VARIABLES
*********************************************************************************************************
*/

OS_STK        TestStartStk[TEST_TASK_STK_SIZE];       /* Tasks stacks                                  */

OS_STK        TestTaskStk[TEST_N_TASKS][TEST_TASK_STK_SIZE];

OS_EVENT     *TestRandomSem;
char          TestTaskData[TEST_N_TASKS];             /* Parameters to pass to each task               */

OS_EVENT     *TestTerminalMbox;
INT16U        TestTerminalMsgCtr;
OS_STK        TestTerminalTaskStk[TEST_TASK_STK_SIZE];

INT16U        TestDly;
INT16U        TestLoops;

/*
*********************************************************************************************************
*                                           FUNCTION PROTOTYPES
*********************************************************************************************************
*/

static  void  TestStart(void *data);                  /* Function prototypes of Startup task           */
static  void  TestTask(void *data);

static  void  TestTerminalCallback(INT8U data);
static  void  TestTerminalTask(void *pdata);

static  void  TestCreateTasks(void);
static  void  TestDisp(void);
static  void  TestDispInit(void);
static  void  TestDispStat(void);

static  void  TestDispTaskData(void);

/*$PAGE*/
/*
*********************************************************************************************************
*                                                MAIN
*********************************************************************************************************
*/

void  main (void)
{
	INT8U  prio;
    INT8U  err;


    OSInit();                                              /* Initialize uC/OS-II                      */

    PC_DOSSaveReturn();                                    /* Save environment to return to DOS        */
    PC_VectSet(uCOS, OSCtxSw);                             /* Install uC/OS-II's context switch vector */

    printf("uC/OS-II and uC/OS-View on 80x86 (Large).\n");

    prio = 0;
    OSTaskCreateExt(TestStart, 
                    (void *)0, 
                    &TestStartStk[TEST_TASK_STK_SIZE - 1], 
                    prio,
                    prio,
                    &TestStartStk[0],
					TEST_TASK_STK_SIZE,
                    (void *)0,
                    OS_TASK_OPT_STK_CLR + OS_TASK_OPT_STK_CHK);
    OSTaskNameSet(prio, "Start Task", &err);

    OSStart();                                             /* Start multitasking                       */
}


/*
*********************************************************************************************************
*                                              STARTUP TASK
*********************************************************************************************************
*/
static  void  TestStart (void *pdata)
{
#if OS_CRITICAL_METHOD == 3                                /* Allocate storage for CPU status register */
    OS_CPU_SR  cpu_sr;
#endif
    char       s[100];
    INT16S     key;
    INT32U     cycles;


    pdata = pdata;                                         /* Prevent compiler warning                 */

    OS_ENTER_CRITICAL();
    PC_VectSet(0x08, OSTickISR);                           /* Install uC/OS-II's clock tick ISR        */
    PC_SetTickRate(OS_TICKS_PER_SEC);                      /* Reprogram tick rate                      */
    OS_EXIT_CRITICAL();

    OSStatInit();                                          /* Initialize uC/OS-II's statistics         */

    OSView_Init();                                         /* Initialize uC/OS-View                    */

    TestTerminalMbox = OSMboxCreate((void *)0);
    OSView_TerminalRxSetCallback(TestTerminalCallback);    /* Setup Terminal callback function         */

    TestCreateTasks();                                     /* Create all the application tasks         */

    PC_DispClrScr(DISP_FGND_WHITE);

    TestDispInit();

    TestDly   = 100;
	TestLoops = 250;
    while (TRUE) {
        if (PC_GetKey(&key) == TRUE) {                     /* See if key has been pressed              */
            switch (key) {                                 
                case 0x1B:                                 /* See if it's the ESCAPE key               */
			         OSView_Exit();
                     PC_DOSReturn();                       /* Return to DOS                            */
                     break;

                case '+':                                  /* Increase task execution rate             */
                case '=':
                     if (TestDly > 10) {
                         TestDly -= 5;
                     } else if (TestDly > 0) {
                         TestDly--;
					 }
                     break;
                                                           /* Decrease task execution rate             */
                case '-':
                case '_':
                     if (TestDly < 10) {
                         TestDly++;
                     } else if (TestDly <= 95) {
					     TestDly += 5;
					 }
                     break;

                case 'U':                                  /* Increase task execution time             */ 
                case 'u':
                     if (TestLoops <= 990) {
					     TestLoops += 10;
					 }
                     break;

                case 'D':                                  /* Decrease task execution time             */
                case 'd':
                     if (TestLoops > 20) {
                         TestLoops -= 10;
					 }
                     break;
            }
        }

		TestDispStat();
        TestDispTaskData();

        PC_GetDateTime(s);
        PC_DispStr(60, 23, s, DISP_FGND_YELLOW + DISP_BGND_BLUE);

        cycles = OSView_TimeGetCycles();
        sprintf(s, "%10lu", cycles);
        PC_DispStr(60, 24, s, DISP_FGND_YELLOW + DISP_BGND_BLUE);

        OSTimeDly(OS_TICKS_PER_SEC / 10);
    }
}

/*$PAGE*/
/*
*********************************************************************************************************
*                             HANDLE VIEWER's TERMINAL WINDOW KEYSTROKES
*
* Note(s): This function is called from an ISR.
*********************************************************************************************************
*/

static  void  TestTerminalCallback (INT8U data)
{
    OSMboxPost(TestTerminalMbox, (char *)data);
}


/*
*********************************************************************************************************
*                             HANDLE VIEWER's TERMINAL WINDOW KEYSTROKES
*********************************************************************************************************
*/

static  void  TestTerminalTask (void *pdata)
{
#if OS_CRITICAL_METHOD == 3                                /* Allocate storage for CPU status register */
    OS_CPU_SR  cpu_sr;
#endif
    char       s[100];
    char       key;
    INT8U      err;


    pdata = pdata;                                         /* Prevent compiler warning                 */
    while (TRUE) {
        key = (char)OSMboxPend(TestTerminalMbox, 0, &err);
        TestTerminalMsgCtr++;
        sprintf(s, "%05u", TestTerminalMsgCtr);
        PC_DispStr(60, 22, s, DISP_FGND_YELLOW + DISP_BGND_BLUE);
        switch (key) {
            case '1':
                 sprintf(s, "\nCPU Usage = %3u%%\n", OSCPUUsage);
                 OSView_TxStr(s, 1);
                 break;

            case '2':
                 sprintf(s, "\n#Tasks    = %3u\n", OSTaskCtr);
                 OSView_TxStr(s, 1);
                 break;

            default:
                 OSView_TxStr("\n\nMicrium, Inc.",       1);
                 OSView_TxStr("\n1: CPU Usage (%)",      1);
                 OSView_TxStr("\n2: #Tasks",             1);
                 OSView_TxStr("\n?: Help (This menu)\n", 1);
                 break;
        }
    }
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                             CREATE TASKS
*********************************************************************************************************
*/

static  void  TestCreateTasks (void)
{
	INT8U  prio;
    INT8U  err;
    INT8U  i;
    char   s[20];


    prio = 1;
    OSTaskCreateExt(TestTerminalTask,                      /* uC/OS-View Terminal task                 */
                    (void *)0, 
                    &TestTerminalTaskStk[TEST_TASK_STK_SIZE - 1], 
                    prio,
                    prio,
                    &TestTerminalTaskStk[0],
				    TEST_TASK_STK_SIZE,
                    (void *)0,
                    OS_TASK_OPT_STK_CLR + OS_TASK_OPT_STK_CHK);
    OSTaskNameSet(prio, "uC/OS-View Terminal", &err);

    for (i = 0; i < TEST_N_TASKS; i++) {
        sprintf(s, "Task #%2d", i + 1);
        TestTaskData[i] = '0' + i;                         /* Each task will display its own letter    */
        prio            = i + 2;
        OSTaskCreateExt(TestTask, 
                        (void *)&TestTaskData[i], 
                        &TestTaskStk[i][TEST_TASK_STK_SIZE - 1], 
                        prio,
                        prio,
                        &TestTaskStk[i][0],
					    TEST_TASK_STK_SIZE,
                        (void *)0,
                        OS_TASK_OPT_STK_CLR + OS_TASK_OPT_STK_CHK);
        OSTaskNameSet(prio, s, &err);
    }
}

/*
*********************************************************************************************************
*                                         IDENTICAL TASK
*********************************************************************************************************
*/
static  void  TestTask (void *pdata)
{
#if OS_CRITICAL_METHOD == 3                      /* Allocate storage for CPU status register           */
    OS_CPU_SR  cpu_sr;
#endif
    INT8U      x;
    INT8U      y;
    INT8U      err;
	INT16U     i;

        

    pdata = pdata;                               /* Prevent compiler warning                           */
    while (TRUE) {
#if 1
        OSSemPend(TestRandomSem, 0, &err);       /* Acquire semaphore to perform random numbers        */
        if (OSTCBCur->OSTCBPrio == 2) {          /* Consume more processing time for task prio. #2     */
		    for (i = 0; i < TestLoops * 50; i++) {
                x = random(80);                  /* Find X position where task number will appear      */
                y = random(10);                  /* Find Y position where task number will appear      */
		    }
        } else {    
		    for (i = 0; i < TestLoops; i++) {
                x = random(80);                  /* Find X position where task number will appear      */
                y = random(10);                  /* Find Y position where task number will appear      */
		    }
        }
        PC_DispChar(x, y + 2, *(char *)pdata, DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
        OSSemPost(TestRandomSem);                /* Release semaphore                                  */
                                                 /* Display the task number on the screen              */
        OSTimeDly(TestDly);
#else
        x = random(80);                          /* Find X position where task number will appear      */
        y = random(10);                          /* Find Y position where task number will appear      */
        PC_DispChar(x, y + 2, *(char *)pdata, DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
        OSTimeDly(TestDly);
#endif
    }
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                        INITIALIZE THE DISPLAY
*********************************************************************************************************
*/

static  void  TestDispInit (void)
{
/*                                1111111111222222222233333333334444444444555555555566666666667777777777 */
/*                      01234567890123456789012345678901234567890123456789012345678901234567890123456789 */
    PC_DispStr( 0,  0, "                             uC/OS-II and uC/OS-View                            ", DISP_FGND_WHITE  + DISP_BGND_RED + DISP_BLINK);
    PC_DispStr( 0,  1, "                                   Micrium, Inc.                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0,  2, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0,  3, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0,  4, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0,  5, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0,  6, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0,  7, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0,  8, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0,  9, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 10, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 11, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 12, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 13, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 14, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 15, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 16, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 17, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 18, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 19, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 20, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 21, "                                                                                ", DISP_FGND_BLACK  + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 22, "#Tasks   :             Task Dly Ticks:                                          ", DISP_FGND_YELLOW + DISP_BGND_BLUE);
    PC_DispStr( 0, 23, "CPU Usage:      %      Task #Loops   :                                          ", DISP_FGND_YELLOW + DISP_BGND_BLUE);
    PC_DispStr( 0, 24, "                            <-PRESS 'ESC' TO QUIT->                             ", DISP_FGND_YELLOW + DISP_BGND_BLUE);
/*                                1111111111222222222233333333334444444444555555555566666666667777777777 */
/*                      01234567890123456789012345678901234567890123456789012345678901234567890123456789 */
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                           UPDATE THE DISPLAY
*********************************************************************************************************
*/

static  void  TestDispStat (void)
{
    char   s[80];
    INT8U  err;
    


    sprintf(s, "%5u", OSTaskCtr);                                  /* Display #tasks running               */
    PC_DispStr(11, 22, s, DISP_FGND_YELLOW + DISP_BGND_BLUE);

#if OS_TASK_STAT_EN > 0
    sprintf(s, "%5d", OSCPUUsage);                                 /* Display CPU usage in %               */
    PC_DispStr(11, 23, s, DISP_FGND_YELLOW + DISP_BGND_BLUE);
#endif

    sprintf(s, "%4u", TestDly);
    PC_DispStr(40, 22, s, DISP_FGND_YELLOW + DISP_BGND_BLUE);

    sprintf(s, "%4u", TestLoops);
    PC_DispStr(40, 23, s, DISP_FGND_YELLOW + DISP_BGND_BLUE);

    sprintf(s, "V%1d.%02d", OSVersion() / 100, OSVersion() % 100); /* Display uC/OS-II's version number    */
    PC_DispStr(75, 24, s, DISP_FGND_YELLOW + DISP_BGND_BLUE);

    switch (_8087) {                                               /* Display whether FPU present          */
        case 0:
             PC_DispStr(71, 22, " NO  FPU ", DISP_FGND_YELLOW + DISP_BGND_BLUE);
             break;

        case 1:
             PC_DispStr(71, 22, " 8087 FPU", DISP_FGND_YELLOW + DISP_BGND_BLUE);
             break;

        case 2:
             PC_DispStr(71, 22, "80287 FPU", DISP_FGND_YELLOW + DISP_BGND_BLUE);
             break;

        case 3:
             PC_DispStr(71, 22, "80387 FPU", DISP_FGND_YELLOW + DISP_BGND_BLUE);
             break;
    }

    switch (OSTickStepState) {
        case OS_TICK_STEP_DIS:
             PC_DispStr(0, 24, "Tick Step Mode Disabled", DISP_FGND_YELLOW + DISP_BGND_BLUE);
             break;

        case OS_TICK_STEP_WAIT:
             PC_DispStr(0, 24, "Tick Step Mode Waiting ", DISP_FGND_YELLOW + DISP_BGND_BLUE);
             break;

        case OS_TICK_STEP_ONCE:
             PC_DispStr(0, 24, "Tick Step Mode Step 1  ", DISP_FGND_YELLOW + DISP_BGND_BLUE);
             break;
    }
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                      DISPLAY TASK EXECUTION TIMES
*********************************************************************************************************
*/
static  void  TestDispTaskData (void)
{
    OS_TCB  *ptcb;
    INT8U    prio;
    INT8U    row;
    INT8U    col;
    char     s[20];


    for (prio = 0; prio <= OS_IDLE_PRIO; prio++) {
        ptcb = OSTCBPrioTbl[prio];
        row  = prio & 0x07;                                                    /* Find position where to display timer value            */
        col  = prio >> 3;
        if (ptcb != (OS_TCB *)0 && ptcb != (OS_TCB *)1) {                      /* Make sure task exist and it's not reserved as a Mutex */
            sprintf(s, "%10lu", ptcb->OSTCBCyclesTot);
    	} else {
            sprintf(s, "%10lu", 0L);
        }
        PC_DispStr(col * 10, row + 13, s, DISP_FGND_WHITE + DISP_BGND_RED);
	}
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                       OS INITIALIZATION HOOK
*                                            (BEGINNING)
*********************************************************************************************************
*/
#if OS_CPU_HOOKS_EN == 0
void  OSInitHookBegin (void)
{
}
#endif

/*
*********************************************************************************************************
*                                       OS INITIALIZATION HOOK
*                                               (END)
*********************************************************************************************************
*/
#if OS_CPU_HOOKS_EN == 0
void  OSInitHookEnd (void)
{
}
#endif

/*
*********************************************************************************************************
*                                          TASK CREATION HOOK
*********************************************************************************************************
*/
#if OS_CPU_HOOKS_EN == 0
void  OSTaskCreateHook (OS_TCB *ptcb)
{
    OSView_TaskCreateHook(ptcb);
}
#endif

/*$PAGE*/
/*
*********************************************************************************************************
*                                           TASK DELETION HOOK
*********************************************************************************************************
*/
#if OS_CPU_HOOKS_EN == 0
void  OSTaskDelHook (OS_TCB *ptcb)
{
    ptcb = ptcb;                                            /* Prevent compiler warning                        */
}
#endif

/*
*********************************************************************************************************
*                                             IDLE TASK HOOK
*********************************************************************************************************
*/
#if OS_CPU_HOOKS_EN == 0
void  OSTaskIdleHook (void)
{
}
#endif

/*
*********************************************************************************************************
*                                           STATISTIC TASK HOOK
*********************************************************************************************************
*/

#if OS_CPU_HOOKS_EN == 0
void  OSTaskStatHook (void)
{
}
#endif

/*$PAGE*/
/*
*********************************************************************************************************
*                                           TASK SWITCH HOOK
*********************************************************************************************************
*/
#if OS_CPU_HOOKS_EN == 0
void  OSTaskSwHook (void)
{
    OSView_TaskSwHook();
}
#endif

/*
*********************************************************************************************************
*                                           OSTCBInit() HOOK
*********************************************************************************************************
*/
#if OS_CPU_HOOKS_EN == 0
void  OSTCBInitHook (OS_TCB *ptcb)
{
    ptcb = ptcb;                                            /* Prevent Compiler warning                        */
}
#endif

/*
*********************************************************************************************************
*                                               TICK HOOK
*********************************************************************************************************
*/
#if OS_CPU_HOOKS_EN == 0
void  OSTimeTickHook (void)
{
    OSView_TickHook();
}
#endif
